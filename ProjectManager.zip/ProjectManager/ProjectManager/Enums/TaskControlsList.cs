﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManager
{
    enum TaskControlsList
    {
        CreateEditTaskControl = 0,
        Preview = 1,
        SideBarList = 2,
    }
}
