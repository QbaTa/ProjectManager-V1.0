﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectManager
{
    enum PagesList
    {
        /// <summary>
        /// Login page
        /// </summary>
        LoginPage = 0,

        /// <summary>
        /// Main page
        /// </summary>
        MainPage = 1,
    }
}
